export const datafields = {
    titlelist: ["SEO","BRANDING","LOGO"],
    SEO: "It is long established fact that a reader will be distracted by the",
    BRANDING: "It is brandingg description branding description",
    LOGO: " logo description logo description logo description logo description logo description "
}